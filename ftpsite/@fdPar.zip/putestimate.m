function fdParobj = putestimate(fdParobj, estimate)
%  Replace the estimate parameter

fdParobj.estimate = estimate;